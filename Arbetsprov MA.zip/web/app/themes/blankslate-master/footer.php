</div>
<footer id="footer">
    <p>© Recruitify 2021</p>
</footer>
</div>
<?php wp_footer(); ?>
</body>
</html>
